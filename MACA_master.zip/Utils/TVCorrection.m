function y_new = TVCorrection(x, gamma)
    % Total variation implemented using the approximate (exact in 1D) 
    % equivalence between the TV norm and the l_1 norm of the Haar (heaviside) coefficients.

    [n,J] = quadlength(x);
    maskpad = zeros(2^J, 2^J);
    maskpad(1 : size(x,1), 1 : size(x,2)) = x;
    qmf = MakeONFilter('Haar');

    uwc = FWT2_TI(maskpad, 1, qmf);
    uwc = SoftThresh(uwc, gamma);
    % Reconstruct.
    y = IWT2_TI(uwc, 1, qmf);
    y_new = y(1 : size(x,1),1 : size(x,2));
end
