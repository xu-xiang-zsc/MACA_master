
function C = HardThreshCoeffs(C,lambda,inverse)
    % C is p*n, p is the atom number in dictionary and n is the pixel number in measurement y.
    % hardthreshold for each column in C
    if inverse==1
        for i=1:size(C,2)
            coeffs = C(:,i);
            coeffs = coeffs.* (abs(coeffs) < lambda);
            C(:,i)= coeffs;
        end
    else
        for i=1:size(C,2)
            coeffs = C(:,i);
            coeffs = coeffs.* (abs(coeffs) > lambda);
            C(:,i)= coeffs;
        end
    end
end