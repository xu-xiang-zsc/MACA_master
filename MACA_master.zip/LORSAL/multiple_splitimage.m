function p = multiple_splitimage(tests, trains, w, scales,sigma, classnum)

x = tests;
clear tests;
dists = cell(1,classnum);
dists2 = cell(1,classnum);
ks = cell(1,classnum);
ks2 = cell(1,classnum);

[d,n] =size(x{1});
n1 = floor(n/80);
p = [];

for i = 1:79
    
    for j=1:classnum
        
        nz = sum(trains{j}.^2);
        temp = x{j};
        x1 = temp(:,((i-1)*n1+1):n1*i);
        nx1 = sum(x1.^2);
        [X1,Z1] = meshgrid(nx1,nz);
        clear nx1;
        dists{j} = Z1-2*trains{j}'*x1+X1;
        ks{j} = exp(-dists{j}/2/scales(j)/sigma^2);
    end
    
    ks_sum = ks{1};
    for t=2:classnum
        ks_sum = ks_sum + ks{t};
    end
    
    K1 = [ones(1,n1); (ks_sum)/classnum];
    p1=mlogistic(w,K1);
    p = [p p1];
end

for j=1:classnum
    temp = x{j};
    x1 = temp(:,(79*n1+1):n);
    clear temp;
    nx1 = sum(x1.^2);
    nz = sum(trains{j}.^2);
    [X1,Z1] = meshgrid(nx1,nz);
    dists2{j} = Z1-2*trains{j}'*x1+X1;
    ks2{j} = exp(-dists2{j}/2/scales(j)/sigma^2);
end

ks_sum2 = ks2{1};
for t=2:classnum
    ks_sum2 = ks_sum2 + ks2{t};
end
    
K2 = [ones(1,n-79*n1); (ks_sum2)/classnum];
p2=mlogistic(w,K2);
p = [p p2];