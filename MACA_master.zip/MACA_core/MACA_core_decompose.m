%% Core of the Decomposition of the Multiple Attribute Component from the original image data

function [output_features] = MACA_core_decompose(in_options)

% get the inputs

img = in_options.img;

pars11 = in_options.pars11; % the coarsest scale of Curvelet transform

pars21 = in_options.pars21; % frequency for Gabor transform
pars22 = in_options.pars22; % scale level for Gabor transform
pars23 = in_options.pars23; % orientation for Gabor transform

itermax = in_options.itermax; % maximum number of main iteration

tvregparam 	= in_options.tvregparam; % TV regularization parameter (usually applied to the cartoon features)
tvcomponent	= in_options.tvcomponent; % component to which TV regularization is applied,1 for cartoon and 2 for texture

epsilon_terminate = in_options.epsilon; % stop criterion
display = in_options.display;

window_size = in_options.window_size; % image block size (i.e., 8*8)
num_blocks   = in_options.num_blocks; % number of the randomly chosen image blocks

lambda_1 = in_options.lambda_1; % penalization parameter for the cartoon features
lambda_2 = in_options.lambda_2; % penalization parameter for the texture features

gamma_coeffs_1 = in_options.gamma_coeffs_1; % hard threshold for coefficients of the cartoon features
gamma_coeffs_2 = in_options.gamma_coeffs_2; % hard threshold for coefficients of the texture features

iteration = in_options.iteration; % number of iteration for SUnSAL
positivity = in_options.positivity; % for SUnSAL


%% 
[parts, x_hat] = MACA_content(img,pars11,pars21,pars22,pars23,itermax,tvregparam,...
    tvcomponent,epsilon_terminate,display,window_size,num_blocks,...
    lambda_1,lambda_2,gamma_coeffs_1,gamma_coeffs_2,iteration,positivity);

%output
output_data.c = squeeze(parts(:,:,1));
output_data.t = squeeze(parts(:,:,2));
output_data.c_t_sum = squeeze(sum(parts,3));
output_data.r = img-squeeze(sum(parts,3));
temp = zeros(size(output_data.c,1)*size(output_data.c,2),2);
temp(:,1) = reshape(output_data.c,size(output_data.c,1)*size(output_data.c,2),1);
temp(:,2) = reshape(output_data.t,size(output_data.t,1)*size(output_data.t,2),1);
temp = reshape(temp,size(output_data.c,1),size(output_data.c,2),2);
output_data.c_t_stack = temp;
output_data.x_hat = x_hat;

output_features.content = output_data;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[parts,x_hat] = MACA_coarseness(img,itermax,tvregparam,...
    epsilon_terminate,display,window_size,num_blocks,...
    lambda_1,lambda_2,gamma_coeffs_1,gamma_coeffs_2,iteration,positivity);

%output
output_data.c = squeeze(parts(:,:,1));
output_data.t = squeeze(parts(:,:,2));
output_data.c_t_sum = squeeze(sum(parts,3));
output_data.r = img-squeeze(sum(parts,3));
temp = zeros(size(output_data.c,1)*size(output_data.c,2),2);
temp(:,1) = reshape(output_data.c,size(output_data.c,1)*size(output_data.c,2),1);
temp(:,2) = reshape(output_data.t,size(output_data.t,1)*size(output_data.t,2),1);
temp = reshape(temp,size(output_data.c,1),size(output_data.c,2),2);
output_data.c_t_stack = temp;
output_data.x_hat = x_hat;

output_features.coarseness = output_data;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[parts,x_hat] = MACA_contrast(img,itermax,tvregparam,...
    epsilon_terminate,display,window_size,num_blocks,...
    lambda_1,lambda_2,gamma_coeffs_1,gamma_coeffs_2,iteration,positivity);

%output
output_data.c = squeeze(parts(:,:,1));
output_data.t = squeeze(parts(:,:,2));
output_data.c_t_sum = squeeze(sum(parts,3));
output_data.r = img-squeeze(sum(parts,3));
temp = zeros(size(output_data.c,1)*size(output_data.c,2),2);
temp(:,1) = reshape(output_data.c,size(output_data.c,1)*size(output_data.c,2),1);
temp(:,2) = reshape(output_data.t,size(output_data.t,1)*size(output_data.t,2),1);
temp = reshape(temp,size(output_data.c,1),size(output_data.c,2),2);
output_data.c_t_stack = temp;
output_data.x_hat = x_hat;

output_features.contrast = output_data;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[parts,x_hat] = MACA_horizontal(img,itermax,tvregparam,...
    epsilon_terminate,display,window_size,num_blocks,...
    lambda_1,lambda_2,gamma_coeffs_1,gamma_coeffs_2,iteration,positivity);

%output
output_data.c = squeeze(parts(:,:,1));
output_data.t = squeeze(parts(:,:,2));
output_data.c_t_sum = squeeze(sum(parts,3));
output_data.r = img-squeeze(sum(parts,3));
temp = zeros(size(output_data.c,1)*size(output_data.c,2),2);
temp(:,1) = reshape(output_data.c,size(output_data.c,1)*size(output_data.c,2),1);
temp(:,2) = reshape(output_data.t,size(output_data.t,1)*size(output_data.t,2),1);
temp = reshape(temp,size(output_data.c,1),size(output_data.c,2),2);
output_data.c_t_stack = temp;
output_data.x_hat = x_hat;

output_features.horizontal = output_data;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[parts,x_hat] = MACA_vertical(img,itermax,tvregparam,...
    epsilon_terminate,display,window_size,num_blocks,...
    lambda_1,lambda_2,gamma_coeffs_1,gamma_coeffs_2,iteration,positivity);

%output
output_data.c = squeeze(parts(:,:,1));
output_data.t = squeeze(parts(:,:,2));
output_data.c_t_sum = squeeze(sum(parts,3));
output_data.r = img-squeeze(sum(parts,3));
temp = zeros(size(output_data.c,1)*size(output_data.c,2),2);
temp(:,1) = reshape(output_data.c,size(output_data.c,1)*size(output_data.c,2),1);
temp(:,2) = reshape(output_data.t,size(output_data.t,1)*size(output_data.t,2),1);
temp = reshape(temp,size(output_data.c,1),size(output_data.c,2),2);
output_data.c_t_stack = temp;
output_data.x_hat = x_hat;

output_features.vertical = output_data;

