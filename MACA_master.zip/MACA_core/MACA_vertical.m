% Horizontal & Vertical, use SWT(stationary wavelet transform)

function [parts, x_hat] = MACA_vertical(img, tvregparam, itermax, epsilon, ...
    display, window_size, num_blocks, lambda_1, lambda_2, ...
    gamma_coeffs_1, gamma_coeffs_2, iteration, positivity)

    tvcomponent = 1;

    [N, M] = size(img);
    imgpad(1:N, 1:M) = img;

    part = zeros(N, M, 2);

    % initialize the dictionaries
    index = randperm(min(N-2*window_size,M-2*window_size),num_blocks)+window_size;
    patches = zeros(window_size, window_size, length(index));

    if display
        fig = figure(100);
        clf(fig);
        subplot(2, 3, 1);imagesc(imgpad(1:N,1:M));axis image;rmaxis;title('Raw');drawnow;
        subplot(2, 3, 2);imagesc(sum(part(1:N,1:M,:),3));axis image;rmaxis;title('\Sigma_i MC_i');drawnow;
        for np = 1:2
            subplot(2, 3, np+3);imagesc(part(1:N,1:M,np));axis image;rmaxis;title(sprintf('MC_%d',np));drawnow;
        end
        subplot(2, 3, 6);imagesc(imgpad(1:N,1:M)-sum(part(1:N,1:M,:),3));axis image;rmaxis;title('Residual');drawnow;
     end

    % initialize the residual
    residual = imgpad-sum(part,3);%Residual=X-X_{t}-X_{c}
    x_hat = zeros(window_size^2*num_blocks,N*M,2);%sparse coefficients in column


    %% main loop
    for iter = 1 : itermax
        epsilon_back = std2(residual);

        for nb = 1 : 2
            Ra = part(:,:,nb) + residual; % X_{c}+residual
            clear residual;

            % vertical first
            if nb == 1
                % unpdate the dictionary 1
                dict_stack_vertical = [];
                clear coeff;
                dictionary_atom = zeros(window_size, window_size);
                for i = 1:length(index)
                    patches(:,:,i) = Ra(index(i)-window_size/2+1:index(i)+window_size/2,index(i)-window_size/2+1:index(i)+window_size/2);
                    coeff = double(patches(:,:,i));

                    % Apply stationary wavelet thresholding to each image for reconstruct.
                    coeff = stationary_wavelet_v(coeff, 'v');
                    coeff = HardThreshCoeffs(coeff, gamma_coeffs_1, 0);
                    dictionary_atom = coeff;

                    dict_stack_vertical = [dict_stack_vertical reshape(dictionary_atom,1,window_size^2)];                                
                    clear dictionary_atom;
                end

                % sunsal
                % in order to use SWT��need to expand image length to power(2,N)
                inits = size(Ra); % initial size
                Ra_temp = expand_edge(Ra, inits(1), inits(2)); % expand image size
                % use stationary wavelet thresholding for image transform
                Ra_temp = stationary_wavelet_v(Ra_temp, 'v');            
                %recover image to initial size
                Ra_temp = shrink_edge(Ra_temp, inits(1), inits(2));

                Ra_temp_new = reshape(Ra_temp,1,size(Ra_temp,1)*size(Ra_temp,2));
                num_i = 3e4;
                if (size(Ra_temp,1)*size(Ra_temp,2)>num_i)
                    sparse_coding_time = fix(size(Ra_temp,1)*size(Ra_temp,2)/num_i);
                    for i = 1 : sparse_coding_time
                        x_hat(:,1+num_i*(i-1):num_i*i,nb) = sunsal(dict_stack_vertical,Ra_temp_new(1+num_i*(i-1):num_i*i),'lambda',lambda_1,'ADDONE','no','POSITIVITY',positivity, ...
                            'AL_iters',iteration,'TOL', 1e-4,'verbose','yes');
                        fprintf('sunsal for %d%s%d\n',1+num_i*(i-1),':',num_i*i);
                    end
                    x_hat(:,1+num_i*sparse_coding_time:end,nb) = sunsal(dict_stack_vertical,Ra_temp_new(1+num_i*sparse_coding_time:end),'lambda',lambda_1,'ADDONE','no','POSITIVITY',positivity, ...
                        'AL_iters',iteration,'TOL', 1e-4,'verbose','yes');
                    fprintf('sunsal for %d%s%d\n',1+num_i*sparse_coding_time,':',size(x_hat,2));
                else
                    x_hat(:,:,nb) = sunsal(dict_stack_vertical,reshape(Ra_temp,1,size(Ra_temp,1)*size(Ra_temp,2)),'lambda',lambda_1,'ADDONE','no','POSITIVITY',positivity, ...
                        'AL_iters',iteration,'TOL', 1e-4,'verbose','yes');
                end

                %hard threshold
                x_hat(:,:,nb) = HardThreshCoeffs(x_hat(:,:,nb), gamma_coeffs_1, 0);
                % Reconstruct image
                part(:,:,nb) = reshape(dict_stack_vertical * x_hat(:,:,nb), N, M);
                residual = imgpad-sum(part,3);

                clear Ra;
                clear Ra_temp;
                clear Ra_temp_new;
                clear dict_stack_vertical;

            elseif nb == 2 
                dict_stack_horizontal = [];
                clear coeff;

                dictionary_atom = zeros(window_size, window_size);
                for i = 1:length(index)
                    patches(:,:,i) = Ra(index(i)-window_size/2+1:index(i)+window_size/2,index(i)-window_size/2+1:index(i)+window_size/2);
                    coeff = double(patches(:,:,i));

                    % Apply SWT to each image pitch for reconstruct.
                    coeff = stationary_wavelet_v(coeff, 'h'); 
                    coeff = HardThreshCoeffs(coeff, gamma_coeffs_2, 0);
                    dictionary_atom  = coeff;
                    dict_stack_horizontal = [dict_stack_horizontal reshape(dictionary_atom,1,window_size^2)];
                    clear dictionary_atom;
                end

                % sunsal
                Ra_temp_new = reshape(Ra, 1, size(Ra, 1)*size(Ra, 2));
                num_i = 3e4;
                if (size(Ra,1)*size(Ra,2) > num_i)
                    sparse_coding_time = fix(size(Ra,1)*size(Ra,2)/num_i);
                    for i = 1 : sparse_coding_time
                        x_hat(:,1+num_i*(i-1):num_i*i,nb) = sunsal(dict_stack_horizontal,Ra_temp_new(1+num_i*(i-1):num_i*i),'lambda',lambda_2,'ADDONE','no','POSITIVITY',positivity, ...
                            'AL_iters',iteration,'TOL', 1e-4,'verbose','yes');
                        fprintf('sunsal for %d%s%d\n',1+num_i*(i-1),':',num_i*i);
                    end
                    x_hat(:,1+num_i*sparse_coding_time:end,nb) = sunsal(dict_stack_horizontal,Ra_temp_new(1+num_i*sparse_coding_time:end),'lambda',lambda_2,'ADDONE','no','POSITIVITY',positivity, ...
                        'AL_iters',iteration,'TOL', 1e-4,'verbose','yes');
                    fprintf('sunsal for %d%s%d\n',1+num_i*sparse_coding_time,':',size(x_hat,2));
                else
                    x_hat(:,:,nb) = sunsal(dict_stack_horizontal,reshape(Ra,1,size(Ra,1)*size(Ra,2)),'lambda',lambda_2,'ADDONE','no','POSITIVITY',positivity, ...
                        'AL_iters',iteration,'TOL', 1e-4,'verbose','yes');
                end

                %hard threshold
                x_hat(:,:,nb) = HardThreshCoeffs(x_hat(:,:,nb), gamma_coeffs_2, 0);
                % Reconstruct
                part(:,:,nb) = reshape(dict_stack_horizontal * x_hat(:,:,nb), N, M);
                residual = imgpad-sum(part,3);%R=X-X_{t}_X{c}

                clear Ra;
                clear Ra_temp_new;
                clear dict_stack_horizontal;
            end
            
            %apply the TV correction for X_{c}
            if (nb == tvcomponent)
                part(:,:,nb) = TVCorrection(part(:,:,nb), tvregparam); 
            end
        end
        
        epsilon_former = std2(residual);
        if (abs(epsilon_back-epsilon_former)<epsilon)
            break;
        end

        % Displays the progress.
        if display
            fig = figure(100);
            %colormap(gray);
            subplot(2,3,1);imagesc(imgpad(1:N,1:M));axis image;rmaxis;title('Raw');drawnow;
            subplot(2,3,2);imagesc(sum(part(1:N,1:M,:),3));axis image;rmaxis;title('\Sigma_i MC_i');drawnow;
            for np = 1:2
                subplot(2,3,np+3);imagesc(part(1:N,1:M,np));axis image;rmaxis;title(sprintf('MC_%d',np));drawnow;
            end
            subplot(2,3,6);imagesc(imgpad(1:N,1:M)-sum(part(1:N,1:M,:),3));axis image;rmaxis;title('Residual');drawnow;
        end
    end

    parts = part(1:N,1:M,:);% output MCs
end