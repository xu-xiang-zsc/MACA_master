%% decompose img into high contrast and low contrast components 
%% by using anisotropic diffusion and shrinking


function [parts,x_hat] = MACA_contrast(img, tvregparam, ...
    itermax, epsilon, display, window_size, num_blocks, ...
    lambda_1, lambda_2, gamma_coeffs_1, gamma_coeffs_2, iteration, positivity)

    tvcomponent = 1; % TV performed on the high contrast component

    [N, M]  = size(img);
    imgpad(1:N, 1:M) = img;

    part = zeros(N, M, 2);

    % initialize the dictionaries
    index = randperm(min(N-2*window_size,M-2*window_size),num_blocks)+window_size;
    patches = zeros(window_size, window_size, length(index));

    if display
        fig = figure(100);
        clf(fig);
        subplot(2,3,1);imagesc(imgpad(1:N,1:M));axis image;rmaxis;title('Raw');drawnow;
        subplot(2,3,2);imagesc(sum(part(1:N,1:M,:),3));axis image;rmaxis;title('\Sigma_i AC_i');drawnow;
        for np = 1:2
            subplot(2,3,np+3);imagesc(part(1:N,1:M,np));axis image;rmaxis;title(sprintf('AC_%d',np));drawnow;
        end
        subplot(2,3,6);imagesc(imgpad(1:N,1:M)-sum(part(1:N,1:M,:),3));axis image;rmaxis;title('Residual');drawnow;
     end

    % initialize the residual
    residual = imgpad - sum(part, 3);%Residual=X-X_{t}-X_{c}
    x_hat = zeros(window_size^2*num_blocks, N*M, 2);%sparse coefficients in column

    % ----------------argument for anisotropic diffusion----------------- %
    num_iter = 15;
    delta_t = 0.02; %1/7;
    kappa = 30;
    option = 2;

    %% main loop
    for iter = 1 : itermax
        epsilon_back = std2(residual);

        for nb = 1 : 2
            Ra = part(:,:,nb) + residual; % X_{c} + residual
            clear residual;

            if nb == 1    
                % update the dictionary 1 : anisotropic diffusion
                dict_stack_anisodiffusion = [];
                clear coeff;
                dictionary_atom = zeros(window_size, window_size);
                for i = 1:length(index)
                    patches(:,:,i) = Ra(index(i)-window_size/2+1:index(i)+window_size/2,index(i)-window_size/2+1:index(i)+window_size/2);
                    coeff = double(patches(:,:,i));

                    % Apply anisotropic diffusion to each pitch for reconstruct.
                    coeff = anisodiffusion(coeff, num_iter, delta_t, kappa, option);
                    coeff = HardThreshCoeffs(coeff, gamma_coeffs_1, 0);   
                    dictionary_atom = coeff;

                    dict_stack_anisodiffusion = [dict_stack_anisodiffusion reshape(dictionary_atom,1,window_size^2)];                                
                    clear dictionary_atom;
                end

                % sunsal
                Ra_temp = anisodiffusion(Ra, num_iter, delta_t, kappa, option);
                Ra_temp_new = reshape(Ra_temp, 1, size(Ra_temp,1)*size(Ra_temp,2));
                num_i = 3e4;
                if (size(Ra_temp,1)*size(Ra_temp,2)>num_i)
                    sparse_coding_time = fix(size(Ra_temp,1)*size(Ra_temp,2)/num_i);
                    for i = 1 : sparse_coding_time
                        x_hat(:,1+num_i*(i-1):num_i*i,nb) = sunsal(dict_stack_anisodiffusion, Ra_temp_new(1+num_i*(i-1):num_i*i),'lambda',lambda_1,'ADDONE','no','POSITIVITY',positivity, ...
                            'AL_iters',iteration,'TOL', 1e-4,'verbose','yes');
                        fprintf('sunsal for %d%s%d\n',1+num_i*(i-1),':',num_i*i);
                    end
                    x_hat(:,1+num_i*sparse_coding_time:end,nb) = sunsal(dict_stack_anisodiffusion, Ra_temp_new(1+num_i*sparse_coding_time:end),'lambda',lambda_1,'ADDONE','no','POSITIVITY',positivity, ...
                        'AL_iters',iteration,'TOL', 1e-4,'verbose','yes');
                    fprintf('sunsal for %d%s%d\n',1+num_i*sparse_coding_time,':',size(x_hat,2));
                else
                    x_hat(:,:,nb) = sunsal(dict_stack_anisodiffusion, reshape(Ra_temp,1,size(Ra_temp,1)*size(Ra_temp,2)),'lambda',lambda_1,'ADDONE','no','POSITIVITY',positivity, ...
                        'AL_iters',iteration,'TOL', 1e-4,'verbose','yes');
                end

                %hard threshold
                x_hat(:,:,nb) = HardThreshCoeffs(x_hat(:,:,nb), gamma_coeffs_1, 0);
                % Reconstruct
                part(:,:,nb) = reshape(dict_stack_anisodiffusion*x_hat(:,:,nb), N, M);
                residual = imgpad-sum(part,3);

                clear Ra;
                clear Ra_temp;
                clear Ra_temp_new;
                clear dict_stack_anisodiffusion;
                
            elseif nb == 2 
                dict_stack_anisoshrink = [];
                clear coeff;
                dictionary_atom = zeros(window_size, window_size);
                for i = 1:length(index)
                    patches(:,:,i) = Ra(index(i)-window_size/2+1:index(i)+window_size/2,index(i)-window_size/2+1:index(i)+window_size/2);
                    coeff = double(patches(:,:,i));

                    % Apply anisotropic shrink to each image pitch for reconstruct.
                    coeff = anisoshrink(coeff, num_iter, delta_t, kappa, option); 
                    coeff = HardThreshCoeffs(coeff, gamma_coeffs_2, 0);   
                    dictionary_atom = coeff;
                    dict_stack_anisoshrink = [dict_stack_anisoshrink reshape(dictionary_atom, 1, window_size^2)];
                    clear dictionary_atom;
                end

                % sunsal
                Ra_temp_new = reshape(Ra, 1, size(Ra,1)*size(Ra,2));
                num_i = 3e4;
                if (size(Ra,1)*size(Ra,2) > num_i)
                    sparse_coding_time = fix(size(Ra,1)*size(Ra,2)/num_i);
                    for i = 1 : sparse_coding_time
                        x_hat(:,1+num_i*(i-1):num_i*i,nb) = sunsal(dict_stack_anisoshrink,Ra_temp_new(1+num_i*(i-1):num_i*i),'lambda',lambda_2,'ADDONE','no','POSITIVITY',positivity, ...
                            'AL_iters',iteration,'TOL', 1e-4,'verbose','yes');
                        fprintf('sunsal for %d%s%d\n',1+num_i*(i-1),':',num_i*i);
                    end
                    x_hat(:,1+num_i*sparse_coding_time:end,nb) = sunsal(dict_stack_anisoshrink,Ra_temp_new(1+num_i*sparse_coding_time:end),'lambda',lambda_2,'ADDONE','no','POSITIVITY',positivity, ...
                        'AL_iters',iteration,'TOL', 1e-4,'verbose','yes');
                    fprintf('sunsal for %d%s%d\n',1+num_i*sparse_coding_time,':',size(x_hat,2));
                else
                    x_hat(:,:,nb) = sunsal(dict_stack_anisoshrink, reshape(Ra,1,size(Ra,1)*size(Ra,2)),'lambda',lambda_2,'ADDONE','no','POSITIVITY',positivity, ...
                        'AL_iters',iteration,'TOL', 1e-4,'verbose','yes');
                end
                
                %hard threshold
                x_hat(:,:,nb) = HardThreshCoeffs(x_hat(:,:,nb), gamma_coeffs_2, 0);
                % Reconstruct
                part(:,:,nb) = reshape(dict_stack_anisoshrink * x_hat(:,:,nb), N, M);
                residual = imgpad-sum(part,3);%R=X-X_{t}_X{c}

                clear Ra;
                clear Ra_temp_new;
                clear dict_stack_anisoshrink;            
            end

            %apply the TV correction for X_{c}
            if (nb == tvcomponent)
                part(:,:,nb) = TVCorrection(part(:,:,nb),tvregparam); 
            end
        end
        
        epsilon_former = std2(residual);
        if (abs(epsilon_back-epsilon_former)<epsilon)
            break;
        end

        % Displays the progress.
        if display
            fig = figure(100);
            %colormap(gray);
            subplot(2,3,1);imagesc(imgpad(1:N,1:M));axis image;rmaxis;title('Raw');drawnow;
            subplot(2,3,2);imagesc(sum(part(1:N,1:M,:),3));axis image;rmaxis;title('\Sigma_i MC_i');drawnow;
            for np = 1:2
                subplot(2,3,np+3);imagesc(part(1:N,1:M,np));axis image;rmaxis;title(sprintf('MC_%d',np));drawnow;
            end
            subplot(2,3,6);imagesc(imgpad(1:N,1:M)-sum(part(1:N,1:M,:),3));axis image;rmaxis;title('Residual');drawnow;
        end
    end

    parts = part(1:N,1:M,:);
end