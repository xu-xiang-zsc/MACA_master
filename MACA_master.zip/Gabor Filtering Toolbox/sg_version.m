%SG_VERSION  - Version string for SimpleGabor toolbox
%
% version = gmmb_version();
%
% $Id: sg_version.m,v 1.1 2007-11-23 08:52:27 jkamarai Exp $

function version = sg_version();

version = 'base2';
