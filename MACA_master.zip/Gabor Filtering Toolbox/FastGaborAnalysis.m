function C = FastGaborAnalysis(img,f,m,n)
% Gabor transform: Returns the real part of each gabor filter
%  Usage:
%    C =  FastGaborAnalysis(Img,L);
%  Inputs:
%    f     frequencies 
%    m     number of frequencies
%    n     number of directions
%  Outputs:
%    C contains the gabor kernel real parts at group of frequency and
%    direction. 
%
%  Description
%    
%f=1/4;m=3;n=4;
% Create Gabor filter bank
gaborBank = sg_createfilterbank(size(img),f,m,n);
% Filter with the filter bank
fResp2 = sg_filterwithbank2(img,gaborBank,'max_zoom',1);
texture=zeros(size(img,1),size(img,2),m*n);
count=1;
for freqInd = 1:size(fResp2.freq,2)
  for orientInd = 1:size(fResp2.freq{1}.resp,1)
    temp=squeeze(real(fResp2.freq{freqInd}.resp(orientInd,:,:)));
    
    texture(:,:,count)=imresize(temp,[size(img,1) size(img,2)]);
    count=count+1;
  end;
end;
C=texture;
	      
	      
